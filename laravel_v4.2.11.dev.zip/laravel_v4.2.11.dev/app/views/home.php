<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Home Page</title>
</head>
<body>

<?php echo $contentId; ?>

</body>
</html>
